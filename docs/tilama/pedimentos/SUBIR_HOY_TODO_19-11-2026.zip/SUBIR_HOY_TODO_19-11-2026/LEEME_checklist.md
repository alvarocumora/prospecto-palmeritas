# Todo lo que se sube hoy, 19-11-2026 (OJV, firma con Clave Única)

Versión revisada a las 17:55. Se suben 20 escritos dentro de causas existentes, 32 pedimentos y manifestaciones nuevos y 1 desistimiento. Hay 8 piezas postergadas en la carpeta C.

Cambios de las 17:45, tras revisar la cobertura de las explotaciones eliminadas del distrito de Tilama:

- MARTINA 15, ELARA 9 y ELARA 16 vuelven al paquete con prioridad B. La señal de molibdeno era un error, pero igual cubren explotaciones históricas: TILAMA 69/80 de ENAMI, NORTE 6 de Compañía Minera Tilama, GRADO 11 y 12 y MACANO 1.
- Se agregan 4 pedimentos nuevos en Los Vilos sobre explotaciones eliminadas que nadie cubría: MARTINA 79 (DON RUFO, ARANTXA 1 y TELETON, al oeste de Chele), MARTINA 80 (TILAMA 1/10 y 11/20 de ENAMI), MARTINA 81 (TILAMA 1, 2 y 3 y MIRADOR) y MARTINA 82 (PUPIO 61/90 y 91/115). Ninguno se superpone con piezas propias; solo MARTINA 82 toca 20 ha de LAS TRES CHEPAS.
- 17:50: se agregan MARTINA 83, 84 y 85 en los tres puntos que marcó Alvy en Google Earth: la zona blanca al oeste de MARTINA 79, el hueco entre ELARA 15, MARTINA 79 y MARTINA 35 (explotaciones antiguas de la familia Del Campo) y el sector sur al oeste de MARTINA 37. Están libres y no se superponen con piezas propias.
- 17:55: se agrega MARTINA 86 (Petorca) sobre labores y desmontes visibles que marcó Alvy a 1.736 m de altura, libres de terceros. Va con prioridad A.

Revisión hecha: los 52 escritos traen el RUT de Valle Escondido SpA y su nacionalidad chilena. Las superficies de cada escrito calzan con la tabla de costos. El datum es PSAD56 en Los Vilos y Petorca, y WGS84 en Illapel y Combarbalá. Las manifestaciones dicen que no se formulan en uso de una concesión de exploración. La única superposición entre piezas propias es MARTINA 32 dentro de MARTINA 33, y es intencional.

## A. En causas ya ingresadas (Juzgado de Letras y Garantía de Los Vilos)

Carpeta `A_causas_ya_ingresadas_cumple_art43_Los_Vilos`. Son 20 escritos de "Cumple lo ordenado", que agregan la nacionalidad de la sociedad. Cada uno se sube **dentro de su rol**: V-303 a V-317 y V-319 a V-323.

- En la OJV: Trámite fácil → Escrito → Civil → Juzgado de Los Vilos → rol V-xxx-2026.
- Plazo: 8 días desde la resolución del 16-11, o sea hasta alrededor del 24-11.
- Se suben todos, también los del grupo 3 del ranking: no cuesta nada y mantiene la opción hasta pagar la tasa (15-12).
- **No** subir nada en V-318 (duplicado, ya desistido) ni en V-328 (ELARA 15).

## B. Causas nuevas (32 escritos + 1 desistimiento)

Carpeta `B_causas_nuevas`. Sube en el orden de los números de cada subcarpeta. Los números que faltan corresponden a piezas que se movieron a la carpeta C.

| Juzgado | Subcarpeta | Escritos |
|---|---|---|
| Letras y Garantía de Los Vilos | 1_LOS_VILOS | 01 MARTINA 37 → **02 desistimiento: se sube DENTRO de la causa V-327-2026** → 03 MARTINA 32 (manifestación) → 04 MARTINA 33, 05 MARTINA 35, 06 MARTINA 12, 07 MARTINA 15, 08 ELARA 9, 09 ELARA 16, 11 MARTINA 16 → 13 LEONOR SUR, 14 LEONOR CENTRO, 15 MARTINA NORTE OESTE y 16 MARTINA NORTE ESTE (manifestaciones) → 17 MARTINA 79, 18 MARTINA 80, 19 MARTINA 81, 20 MARTINA 82, 21 MARTINA 83, 22 MARTINA 84 y 23 MARTINA 85 |
| Letras y Garantía de Petorca | 2_PETORCA | 01 MARTINA 47, 02 MARTINA 54, 03 MARTINA 55, 07 MARTINA 46, 11 MARTINA 69, 12 MARTINA 86 |
| Letras de Illapel | 3_ILLAPEL_Cerro_Alto | LEONOR CERRO ALTO 1 a 4 → 05 LEONOR CERRO ALTO FAENA (manifestación), en WGS84 |
| Letras y Garantía de Combarbalá | 4_COMBARBALA | MARTINA 70, en WGS84 |

- Las manifestaciones van como Minero → Manifestación. Las demás, como Pedimento.
- En cada causa nueva se adjuntan los certificados de estatuto, vigencia y anotaciones de Valle Escondido SpA.
- Si alguna pieza de 1_LOS_VILOS ya se subió el 18-11, **no la repitas**.

### Prioridad al pagar (columna `prioridad` de `orden_y_costos.csv`)

- **A, 15 piezas: pagar tasa, inscribir y publicar.** MARTINA 37, 32, 33 y 35; LEONOR SUR, LEONOR CENTRO, MARTINA NORTE OESTE y ESTE; LEONOR CERRO ALTO 1, 4 y FAENA; MARTINA 47, 54, 55 y 86. Costo: $3.265.590.
- **B, 17 piezas: se suben hoy para tener la prioridad y se decide después de terreno, antes de que venza la tasa (~19-12).** MARTINA 12, 15, 16, 46, 69, 70 y 79 a 85; ELARA 9 y 16; LEONOR CERRO ALTO 2 y 3. Costo si se pagan todas: $4.216.293. La que no se pague, caduca.
- Total si se paga todo: **$7.481.883** ($2.817.915 de tasa y $4.663.968 de boletín). Solo la prioridad A: $3.265.590.

## C. Postergadas: no se suben hoy

Carpeta `C_postergadas_no_subir`: ELARA 17, MARTINA 18, 38, 40, 41, 42, 44 y 49. No hay evidencia que las justifique. Se presentan después solo si el muestreo o un competidor lo justifican.

## Después de subir

1. Guardar el certificado de envío de cada causa y pasármelo para anotar rol, fecha y hora en el control.
2. Tasa: vence a 30 días de cada presentación. Las del 15-11 vencen el 15-12 y sus escritos de pago están en `presentado/escritos_tasa`.
3. Cuando salga cada resolución: inscribir en el Conservador y publicar en el Boletín dentro de 30 días, empezando por las de prioridad A.
4. Las causas del 17-11 que se dejan caducar no se contestan ni se pagan.
